<?php
include("configure.php");
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$sql = "INSERT INTO `portfolio`(`name`, `email`, `subject`,`message`) VALUES ('".$name."','".$email."','".$subject."','".$message."')";
$query= mysqli_query($mysqli,$sql);
if($query){
    header("Location: index.html");
    reset();
    exit();
}
else{
    echo 'Fill correctly';
}
?>